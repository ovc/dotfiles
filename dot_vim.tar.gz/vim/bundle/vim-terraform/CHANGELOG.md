# vim-terraform CHANGELOG

## Version 1.2.1 (February 5, 2015)

-   Block indentation fix (thanks imkira@github)

## Version 1.2.0 (December 12, 2014)

-   Add Kevin Le's syntax highlighting

## Version 1.1.0 (December 11, 2014)

-   Remove syntax highlighting; see README.md

## Version 1.0.1 (December 10, 2014)

-   Make this work without the JSON plugin

## Version 1.0.0 (December 10, 2014)

-   Initial release
